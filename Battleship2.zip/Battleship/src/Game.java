import java.util.Scanner;

public class Game {

    public static void initializeGame() {
        System.out.println("Do you want to play 1v1 (1) or against an AI (2)?\nPlease put your choice below.");
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();

        if (choice == 1) {

        }
        //if (choice == 2) {

       // }

    }

    public static boolean playBattleship1(Board b){
        Scanner pickShipOrientation = new Scanner(System.in);
        System.out.println("Pick an orientation for your first ship (horizontal or vertical)");
        String orientation = pickShipOrientation.nextLine();
        Scanner coordinates = new Scanner(System.in);
        System.out.println("Pick an x-coordinate for the head of your ship (A-J); make sure that it fits on the board!");
        String xCoordinate1 = coordinates.nextLine();
        System.out.println("Pick a y-coordinate for the head of your ship (0-9); make sure that it fits on the board!");
        String yCordinate1 = coordinates.nextLine();



        while(true){
            Scanner yourMove = new Scanner(System.in);
            System.out.println("Pick a coordinate to target (A-J, 0-9)");
            String move = yourMove.nextLine();
        }
    }




}
