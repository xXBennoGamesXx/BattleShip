import java.util.Scanner;

public class Game {

    public static String initializeGame(){
        System.out.println("Do you want to play 1v1 (1) or against an AI (2)?\nPlease put your choice below.");
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();
        if (choice = 1){
            
        }

    }
}
