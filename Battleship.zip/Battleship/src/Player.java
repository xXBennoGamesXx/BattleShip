public class Player {
    String name;
    boolean conditionWin = false;

    public Player(String n){
        this.name = n;
    }

    public String getPlayerName(){
        return this.name;
    }


}
