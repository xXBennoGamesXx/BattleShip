import java.util.Scanner;

public class BattleshipRunner {
    public static void main(String args[]){
        int choice;

    }
}
