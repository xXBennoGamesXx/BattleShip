public class Board {
    private String[][] board;


    private void Board(){
        this.board = new String[][]{new String[10], new String[10], new String[10], new String[10],
                new String[10], new String[10], new String[10], new String[10], new String[10], new String[10]};

    }
    public void displayBoard(){
        System.out.println("A \n B \n C \n D \n E \n F \n G \n H \n I \n J");

    }
}
